import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex);
//其实currentPlayList myLevel currentAudio quarter（link的文字表达）也是使用storage 比较好，因为下次打开的时候，不想再点一遍
const store = new Vuex.Store({
	state:{
		isLogin:false,
		currentAudio:"0000",
		quarter:""
	},
	mutations:{

		SET_AUDIO(state,audio)
		{
			state.currentAudio = audio;
		},
		SET_QUARTER(state,quarter)
		{
			state.quarter = quarter;
		},
	},
	actions:{}
});
export default store
