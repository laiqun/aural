<template>
	<view class="content">
		<view class="uni-list" style="background-color: #F1F1F1;">
			<view class="uni-list-cell">
				<view class="uni-list-cell-left">
					选择当前级别:
				</view>
				<view class="uni-list-cell-db">
					<picker mode="multiSelector" @change="bindPickerChange" :value="index2" :range="levelxx" @columnchange="columnchange">
						<view class="uni-input">{{currentSpec}}</view>
					</picker>
				</view>
			</view>
		</view>
		<progress id="process" :percent="percent" show-info stroke-width="3" style="margin: 5px 0;" />
		<view class="text-area">
			<uni-list>
				<uni-list-item style="height: 36px;" v-for="(item,index) in currentPlayList" badgeType="success" :title="item.title.split(']')[1]"
				 :show-badge="item.finish" badge-text="✔" :key="index" clickable @click="itemclick(item,)"></uni-list-item>

				<!-- 				<uni-list-item  v-for="(item,index) in currentPlayList"  badgeType="warning" :title="item.name" :show-badge="item.finish" badge-text="✔" :key="index" clickable @click="itemclick(item.name,)"></uni-list-item>
 -->
				<!--<uni-list-item  v-for="(item,index) in discList"  badgeType="success" :title="item.name" :show-badge="item.finish" badge-text="✔" :key="item.name" clickable @click="itemclick(item.name,)"></uni-list-item>
				所有都听懂，为绿色； 听了但是有句子没听懂，为黄色-->
			</uni-list>
		</view>
	</view>
</template>

<script>
	// 在页面中定义插屏广告
	let interstitialAd = null;
	export default {
		data() {
			return {
				levelxx: [
					[],
					[]
				],
				levelDict: null,
				levelsArray: "",
				indexleft: 0,
				indexright: 0,
				percent: 0,
				currentPlayList: [],
				index2: [0, 0],
				currentSpec: "",
				intervalFunc:null
			}
		},
		onShow() {
			uni.showTabBar({});
			//判断今天有没有听，如果听了，就显示广告
			try{
				if (interstitialAd) {
					interstitialAd.show().catch((err) => {
						console.error(err)
					})
				}
			}
			catch(e)
			{
				
			}

		},
		onReady() {
			// 在适合的场景显示插屏广告
			//	setTimeout( ()=> {
			// 在适合的场景显示插屏广告

			//},16000);
		},
		onLoad() {
			// 在页面onLoad回调事件中创建插屏广告实例
			if (wx.createInterstitialAd) {
				interstitialAd = wx.createInterstitialAd({
					adUnitId: 'adunit-ccca4b94498d0a35'
				})
				interstitialAd.onLoad(() => {})
				interstitialAd.onError((err) => {})
				interstitialAd.onClose(() => {})
			}

		},
		created: function() {
			console.log("load level array");
			let i = -1;
			let tooltip = ["播放页左滑可以上一句喔", "播放页右滑可以下一句喔", "长按听不懂可以显示全部喔", "听不懂的句子可以点击播放单句", "点击听不懂句子右边的三个点试试"];
			this.loadlevelArray();
			this.intervalFunc = setInterval(function() {
				if(i >= tooltip.length)
					i = 0;
				else
					i = i + 1;
				uni.setNavigationBarTitle({
					title: tooltip[i] // 		title: this.myLevel + this.quarter
				});
			}, 3800);
		},
		onHide:function(){
			clearInterval(this.intervalFunc);
		},
		onShareAppMessage: function() {
			return {
				title: '一句话反复听，带翻译的听力。',
				path: 'pages/alist/index'
			};
		},
		methods: {

			detectFinished: function() {
				//判断是否finished
				console.log("check finished");
				let finishedNumber = 0;
				for (let item of this.currentPlayList) {
					let finished = uni.getStorageSync("finised_" + item["link"]);
					if (finished) {
						item['finish'] = true;
						finishedNumber = finishedNumber + 1;
					} else {
						item['finish'] = false;
					}
				}
				this.percent = (finishedNumber / this.currentPlayList.length).toFixed(2) * 100;
			},
			loadlevelArray: function() {
				let that = this;
				uni.showLoading({
					title: "加载听力列表中",
					mask: true
				});

				uni.downloadFile({
					url: `https://6175-aural-1f8ab2-1302948072.tcb.qcloud.la/levelAndList.json`, //仅为示例，并非真实的资源
					success: (res) => {
						if (res.statusCode === 200) {
							console.log(res["tempFilePath"]);
							if (res["tempFilePath"].indexOf('wxfile://') == 0) {
								uni.getFileSystemManager().readFile({
									filePath: res["tempFilePath"],
									encoding: 'utf-8',
									success: (res) => {
										let levelArray = JSON.parse(res.data);
										//if(that.levelsArray.toString()!= levelArray.toString())
										//	that.levelsArray.splice(0,0,...levelArray);
										if (that.levelsArray.toString() != levelArray.toString())
											that.levelsArray = levelArray;
										that.levelDict = levelArray["levelDict"];
										let keys = Object.keys(that.levelDict);
										that.levelxx[0].splice(0, 0, ...keys);



										//设置indexleft和indexright
										let mylevel;
										let song = uni.getStorageSync("song");
										if (!song.hasOwnProperty('mylevel')) {
											let keyarr = [];
											for (let item of that.levelDict[keys[0]]) {
												keyarr.push(item['name']);
											}
											that.levelxx[1].splice(0, 0, ...keyarr);
											that.currentSpec = that.levelsArray["levelDict"][that.levelxx[0][0]][0].name;
											that.indexleft = 0;
											that.indexright = 0;
											that.index2 = [that.indexleft, that.indexright];
										} else {
											mylevel = song["mylevel"];
											for (let indexleft in keys) {
												for (let indexright in that.levelDict[keys[indexleft]]) {
													if (that.levelsArray["levelDict"][that.levelxx[0][indexleft]][indexright].simplify == mylevel) {
														that.currentSpec = that.levelsArray["levelDict"][that.levelxx[0][indexleft]][indexright].name;
														let keyarr = [];
														for (let item of that.levelDict[keys[indexleft]]) {
															keyarr.push(item['name']);
														}
														that.levelxx[1].splice(0, 0, ...keyarr);
														that.indexleft = parseInt(indexleft);
														that.indexright = parseInt(indexright);
														that.index2 = [that.indexleft, that.indexright];
														break;
													}
												}
											}
										}
										//加载列表
										that.loadList(that.levelsArray["levelDict"][that.levelxx[0][that.indexleft]][that.indexright].simplify);
										uni.getFileSystemManager().removeSavedFile({
											filePath: res["tempFilePath"]
										});
									} //end of success
								}); // read file complete 

							} else {
								uni.request({
									url: res["tempFilePath"],
									header: {
										'content-type': 'application/json'
									},
									success: (res) => {
										let levelArray = res.data;
										if (that.levelsArray.toString() != levelArray.toString())
											that.levelsArray = levelArray;
										that.levelDict = levelArray["levelDict"];
										let keys = Object.keys(that.levelDict);
										that.levelxx[0].splice(0, 0, ...keys);



										//设置indexleft和indexright
										let mylevel;
										let song = uni.getStorageSync("song");
										if (!song.hasOwnProperty('mylevel')) {
											let keyarr = [];
											for (let item of that.levelDict[keys[0]]) {
												keyarr.push(item['name']);
											}
											that.levelxx[1].splice(0, 0, ...keyarr);
											that.currentSpec = that.levelsArray["levelDict"][that.levelxx[0][0]][0].name;
											that.indexleft = 0;
											that.indexright = 0;
											that.index2 = [that.indexleft, that.indexright];
										} else {
											mylevel = song["mylevel"];
											for (let indexleft in keys) {
												for (let indexright in that.levelDict[keys[indexleft]]) {
													if (that.levelsArray["levelDict"][that.levelxx[0][indexleft]][indexright].simplify == mylevel) {
														that.currentSpec = that.levelsArray["levelDict"][that.levelxx[0][indexleft]][indexright].name;
														let keyarr = [];
														for (let item of that.levelDict[keys[indexleft]]) {
															keyarr.push(item['name']);
														}
														that.levelxx[1].splice(0, 0, ...keyarr);
														that.indexleft = parseInt(indexleft);
														that.indexright = parseInt(indexright);
														that.index2 = [that.indexleft, that.indexright];
														break;
													}
												}
											}
										}
										//加载列表
										that.loadList(that.levelsArray["levelDict"][that.levelxx[0][that.indexleft]][that.indexright].simplify);
										uni.getFileSystemManager().removeSavedFile({
											filePath: res["tempFilePath"]
										});
									} //end of success
								});
							}
							uni.hideLoading();
						} // load status 200
						else {
							uni.hideLoading();
							uni.showModal({
								title: "提示",
								content: "听力列表状态异常" + res.statusCode,
								showCancel: false
							});
						}
					},
					fail: (res) => {
						console.log("load level array fail");
						uni.hideLoading();
						uni.showModal({
							title: "提醒",
							content: "听力列表加载失败",
							showCancel: false
						});
					}
				});
			},
			loadList: function(mylevel) {
				let audiolist = this.levelsArray[mylevel];
				for (let item of audiolist) {
					item['finish'] = false;
				}
				this.currentPlayList = audiolist;
				this.detectFinished();
			},
			itemclick: function(e) {
				let stringDate = new Date();
				let strDate = `${stringDate.getFullYear()}/${stringDate.getMonth()+1}/${stringDate.getDate()}`;
				//先读出来，看看有没有  //选中后，保持高亮
				uni.getStorage({
					key: "recentListernList",
					success: (res) => {
						//将这个加入，然后写入
						console.log(res.data);
						for (let i = 0; i < res.data.length; i++) { //先查找，找不到再加入
							if (res.data[i].link == e.link)
								return;
						}
						e["mylevel"] = this.levelsArray["levelDict"][this.levelxx[0][this.indexleft]][this.indexright].simplify;
						res.data.unshift(e); //补充等级信息
						while (res.data.length > 10) {
							res.data.pop();
						}

						uni.setStorage({
							key: "recentListernList",
							data: res.data, //应该把等级信息也放上的
							success: (res) => {
								console.log('data read and write success');
							},
							fail: () => {
								console.log('data read success and write fail');
							}
						});
					},
					fail: () => {
						console.log(e);
						e["mylevel"] = this.levelsArray["levelDict"][this.levelxx[0][this.indexleft]][this.indexright].simplify;
						uni.setStorage({
							key: "recentListernList",
							data: [e],
							success: (res) => {
								console.log('data read fail and write success');
							},
							fail: () => {
								console.log('data read fail and write fail');
							}
						});
					}
				});
				/*记录一下今天听了几个，如果超过3个，弹出激励视频，然后允许继续看3个*/
				uni.getStorage({
					key: "todayListernList",
					success: (res) => {
						//判断一下日期，如果日期不一致

						if (res.data.date == strDate) {
							//如果日期一致
							if (res.data.list.indexOf(e.link) != -1)
								return;
							else {
								let temp = res.data.list;
								temp.push(e.link);
								if (temp.length > 3) {
									console.log("larget than 3");
								}
								uni.setStorage({
									key: "todayListernList",
									data: {
										"date": strDate,
										"list": temp
									}
								});
							}
						} else {
							//data number
							uni.setStorage({
								key: "todayListernList",
								data: {
									"date": strDate,
									"list": [e.link]
								}
							});

						}

					},
					fail: () => {
						console.log(e);
						e["mylevel"] = this.levelsArray["levelDict"][this.levelxx[0][this.indexleft]][this.indexright].simplify;
						//data number
						uni.setStorage({
							key: "todayListernList",
							data: {
								"date": strDate,
								"list": [e.link]
							},
							success: (res) => {
								console.log('data read fail and write success');
							},
							fail: () => {
								console.log('data read fail and write fail');
							}
						});
					}
				});


				uni.setStorageSync("song", {
					"link": e.link,
					"title": e.title.split(']')[1],
					"mylevel": this.levelsArray["levelDict"][this.levelxx[0][this.indexleft]][this.indexright].simplify
				});
				uni.switchTab({
					url: "../aplayer/index"
				});
			},
			bindPickerChange: function(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value);
				//此时是含有两个元素的数组
				this.indexleft = e.detail["value"][0];
				this.indexright = e.detail["value"][1];
				this.index2 = [this.indexleft, this.indexright];
				//this.index = e.detail.value;
				this.currentSpec = this.levelsArray["levelDict"][this.levelxx[0][this.indexleft]][this.indexright].name;
				this.loadList(this.levelsArray["levelDict"][this.levelxx[0][this.indexleft]][this.indexright].simplify);
			},
			columnchange: function(e) {
				//event.detail = {column: column, value: value}
				if (e.detail["column"] == 0) {
					let keys = Object.keys(this.levelDict);
					this.levelxx[1].length = 0;
					let temparr = JSON.parse(JSON.stringify(this.levelDict[keys[e.detail["value"]]]));
					//一个循环，拿到所有namme
					let keyarr = [];
					for (let item of temparr) {
						keyarr.push(item['name']);
					}

					//this.levelxx[1].splice(0,this.levelxx[1].length-1);
					this.levelxx[1].splice(0, 0, ...keyarr);
				}
			}
		}
	}
</script>

<style>


</style>
