<template>
	<view class="container">
		<view class="content citem" :style="lyricstyle" id="lyric">

			<scroll-view style="height: 92px;  overflow: auto;white-space: normal;line-height: 1.8;" v-if="showLyric" scroll-y="true">
				<text style="color: #1AAD19;background-color: #F1F3F4;">{{lyric}}</text>
			</scroll-view>
			<text v-if="showlog">{{loggg}}</text>
			<scroll-view scroll-y="true" :style="notestyle" show-scrollbar="false" v-if="showNotes">
				<view v-for="(item, index) in filters" :key='index' style="line-height: 1.8; border-top:1px solid #e5e5e5;padding: 5px 0; display: flex;align-items: center;justify-content:space-between	 ;"  @tap="playSentence(item)">
					<text style="white-space: normal;">{{item.Value}}</text>
					<image @tap.native.stop="showSentenceCtxMenu(item)" style="height: 22px;width: 22px; flex-shrink:0" src="../../static/ellipsis.png">
					</image>
				</view>
			</scroll-view>

		</view>
		<view class="footer audo-video citem" id="player">
			<button @tap="addToFilter"  @longpress="showAllNotes"  type="primary" style="width: 100%;background-color: #1aad19;border-radius: 10px;height: 46px;text-align: center;line-height: 46px;">这句听不懂
				({{filtersLength}})</button>
			<video id="myVideo" :src="audiosrc" :auto-pause-if-navigate="false" :auto-pause-if-open-native="false"  autoplay="true" class="hidden" @waiting="videowait"	@error="videoerror" @timeupdate="timeupdate" ref="video" @loadedmetadata="loadedmetadata">

			</video>
			
			<view class="slider-box" style="height: 28px;">
				<text class="mm" @tap="showlogfun">{{timer}}</text>
				<slider style="width: 500upx;margin: 5px 18px;" @change="sliderChange" @changing="sliderChanging" class="audio-slider"
				 block-size="16" :min="0" :max="duration" :value="currentTime" activeColor="#ff7400" @touchstart="lock= true"
				 @touchend="lock = false" />
				<text class="ss">{{overTimer}}</text>
			</view>
			<view class="control" id="control" style="line-height: 1;height: 36px;">
				<view class="item iconfont icon-home" @tap="showtabbar"></view>
				<view class="item iconfont icon-edit" @tap="showOrHideNotes" ></view>

				<view @tap='goPrevSentence' class="item iconfont icon-previous">
				</view>
				<view @tap="playAndPause" class="item iconfont" :class="[!playStatus?'icon-movie':'icon-play']">
				</view>
				<view @tap='goNextSentence' class="item iconfont icon-nextsong">
				</view>
				<view class="item iconfont icon-visible" @tap="showOrHideLyric"></view>

				<view class="item" @tap="setPlayRate" style="text-align: center;line-height: 46px;font-size: 23px;">X{{playRate}}</view>

			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapState,
		mapMutations
	} from 'vuex'
	export default {
		props: {
			url: ''
		},
		data() {
			return {
				array: [{
					name: '0.5'
				}, {
					name: '0.75'
				}, {
					name: '1'
				}, {
					name: '1.25'
				}, {
					name: '1.5'
				}, {
					name: '1.75'
				}, {
					name: '2'
				}],
				index: 2,
				lock: false, // 锁
				playStatus: false, // 1暂停 2播放
				currentTime: 0, //当前进度
				duration: 100, // 总进度
				videoContext: '',
				tabbarState: false,
				lyricHeight: 0,
				sentences: [],
				currentSentence: null,
				filters: [],
				showLyric: true,
				lyricMode:0,// 0显示中英文，1 显示英文 
				sentenceEnd: Number.MAX_VALUE,
				isSentenceLoop: false,
				playRate: 1,
				showNotes: true,
				getLyric: false,
				currentAudioServer: "",
				loggg: "",
				showlog: false,
				currentfilter: null,
				currentAudio: "",
				mylevel: "CET4",
				trans: "",
				countTap:0,
				audiosrc:""
			}
		},
		computed: {
			
			timer: function() {
				return calcTimer(this.currentTime)
			},
			lyric: function() {
				if (this.currentSentence) {
					if (this.currentSentence.hasOwnProperty('Value')) {
						if (this.currentSentence.hasOwnProperty('trans')) {
							//判断一下显示模式
							if(this.lyricMode)
								return this.currentSentence["Value"] + "\n" + this.currentSentence["trans"];
							else
								return this.currentSentence["Value"];
						}
						return this.currentSentence["Value"];
					}
				}
				return "";
			},
			overTimer: function() {
				return calcTimer(this.duration)
			},
			lyricstyle: function() {
				return `height: ${this.lyricHeight}px`
			},
			notestyle: function() {
				let noteHeight = this.lyricHeight - 92;
				return `height: ${noteHeight}px;overflow: auto;white-space: normal`
			},
			filtersLength: function() {
				return this.filters.length;
			},
		},

		created() {
			console.log("created");
			this.videoContext = uni.createVideoContext('myVideo');
			uni.setInnerAudioOption({
				obeyMuteSwitch: false
			});
			uni.hideTabBar({});
		},
		mounted() {
			console.log("mounted");
			this.setheight();

		},
		onShow() {
			
			uni.setKeepScreenOn({ //保持屏幕常亮
				keepScreenOn:true
			});
			let that = this;
			uni.hideTabBar({});
			let song = uni.getStorageSync("song");
			if (song) {
				if (song.hasOwnProperty('title') && song["title"].length > 0) {
					uni.setNavigationBarTitle({
						title: song["title"] // 		title: this.myLevel + this.quarter
					});
				}
				if (song.hasOwnProperty('link') && song["link"].length > 0) {
					this.currentAudio = song["link"];
					this.mylevel = song["mylevel"];
				}
				else{
					uni.showModal({
						title:"提示",
						content:"请重选听力选集",
						mask:true,
						showCancel:false,
						complete: () => {
							this.showtabbar();
						}
					});
				}
				let tempaudiosrc =  `https://6175-aural-1f8ab2-1302948072.tcb.qcloud.la/${this.mylevel}/${this.currentAudio}/audio.m4a`;
				if(this.audiosrc != tempaudiosrc)
					this.audiosrc = tempaudiosrc;
				this.loggg = `${this.mylevel}/${this.currentAudio}`;
			}
			else{
				uni.showModal({
					title:"提示",
					content:"请选择听力选集",
					mask:true,
					showCancel:false,
					complete: () => {
						this.showtabbar();
					}
				});
				return;
			}
			// console.log("currentAudioServer: "+this.currentAudioServer);
			// console.log("currentAudio: "+this.currentAudio);
			if (this.currentAudioServer != this.currentAudio||this.sentences.length == 0) {
				uni.showLoading({  // 修改，如果loading ，没有完成，不能播放
					title:"正在加载字幕",
					mask:true
				});
				uni.downloadFile({// 由于跨域限制，所以，只能改用downloadFile
					url: `https://6175-aural-1f8ab2-1302948072.tcb.qcloud.la/${this.mylevel}/${this.currentAudio}/sentences.json`, //仅为示例，并非真实的资源
					success: (res) => {
						if (res.statusCode === 200) {
							console.log('下载成功');
							console.log(res["tempFilePath"]);
							if (res["tempFilePath"].indexOf('wxfile://') == 0) {
								uni.getFileSystemManager().readFile({
									filePath: res["tempFilePath"],
									encoding: 'utf-8',
									success: (res) => {
										//判断一下，如果最后一句的的Value是""，然后trans是null，说明是多余的，应该删掉
										let temp = JSON.parse(res.data);
										if (temp[temp.length - 1].hasOwnProperty("Value") && temp[temp.length - 1].hasOwnProperty("trans")) {
											if (temp[temp.length - 1]["Value"] == "" || temp[temp.length - 1]["trans"] == null)
												temp.pop();
										}
										that.sentences = temp;

									}
								});
								uni.getFileSystemManager().removeSavedFile({
									filePath: res["tempFilePath"]
								});
							} else {
								uni.request({
									url: res["tempFilePath"], 
									header: {
										'content-type': 'application/json'
									},
									success: (res) => {
										console.log(res.data);
										let temp = res.data;
										if (temp[temp.length - 1].hasOwnProperty("Value") && temp[temp.length - 1].hasOwnProperty("trans")) {
											if (temp[temp.length - 1]["Value"] == "" || temp[temp.length - 1]["trans"] == null)
												temp.pop();
										}
										that.sentences = temp;

									}
								});
								uni.getFileSystemManager().removeSavedFile({
									filePath: res["tempFilePath"]
								});	
							}
							uni.hideLoading();
							//直接开始播放
							try{
								this.videoContext.play();
							}
							catch(e){
								console.log('play at start fail');
							}

							this.playStatus = true;
						}// status 200
						else{
							uni.hideLoading();
							uni.showModal({
								title:"提醒",
								content:"加载状态异常"+res.statusCode,
								mask:true,
								showCancel:false
							});
						}
					},
					fail: (res) => {
						uni.hideLoading();
						uni.showModal({
							title:"提示",
							content:"下载字幕失败",
							mask:true,
							showCancel:false
						});
					}
				});
				this.currentAudioServer = this.currentAudio;
				this.currentSentence = null;
				//this.filters = [];
				this.filters.splice(0);// ddelete all
			}
			try {
				this.loadFilters();
			
			} catch (error) {
			
			}

		},
		onLoad() {
			console.log("onload");
		},
		onUnload(){
			console.log("onunload");
		},
		onShareAppMessage: function() {
			return {
				title: '一句话反复听，带翻译的听力。',
				path: 'pages/alist/index'
			};
		},
		methods: {
			videoerror:function(e){
				console.log('video error');
				console.log(e);
			},
			videowait:function(e){
				console.log('video wait');
				console.log(e);
			},
			showlogfun: function() {
				this.countTap = this.countTap + 1;
				if(this.countTap >5)
				{
					this.showlog = !this.showlog;
					this.countTap = 0;
				}
			},
			loadFilters: function() {
				let filtersStorageJSON = uni.getStorageSync("filters_" + this.currentAudio);
				if (filtersStorageJSON) {
					if (JSON.stringify(this.filters) == filtersStorageJSON)
						return;
					this.filters.splice(0); // delete all 
					this.filters.splice(0, 0, ...JSON.parse(filtersStorageJSON)); //https://www.cnblogs.com/shuihanxiao/p/10642265.html   vue无法监听数组变化
					/* this.$nextTick(()=>{
						//Array.prototype.push.apply(this.filters, JSON.parse(filtersStorageJSON));//必须用splice方法，否则监听不到变化
						
					}); */
				}
			},
			setPlayRate: function() {
				let that = this;
				let templist = ["0.5", "0.8", "1", "1.25", "1.5", "2"]; //微信小程序要求是字符串，且不能超过6个  倍率，支持 0.5/0.8/1.0/1.25/1.5，2.6.3 起支持 2.0 倍速
				uni.showActionSheet({
					itemList: templist,
					success: function(res) {
						console.log('选中了第' + (res.tapIndex + 1) + '个按钮');
						console.log(parseFloat(templist[res.tapIndex]));
						that.setRate(parseFloat(templist[res.tapIndex]));
						that.playRate = templist[res.tapIndex];
					},
					fail: function(res) {
						console.log(res.errMsg);
					}
				});
			},
			logSentenceNumber: function() {
				let temp = uni.getStorageSync("achieve");
				let stringDate = new Date();
				let strDate = `${stringDate.getFullYear()}/${stringDate.getMonth()+1}/${stringDate.getDate()}`;
				if (temp) { // if have old data
					if (temp['date'] == strDate) { // if is same date ,just add 
						uni.setStorage({
							key:"achieve",
							data:{
								'date': strDate,
								'number': temp['number'] + 1},
							});
						return;
					}
				}
				uni.setStorage({
					key:"achieve",
					data:{
						'date': strDate,
						'number': 1},
					});
			},
			// 倍速
			setRate: function(num) {
				this.videoContext.playbackRate(num)
			},
			showOrHideLyric: function() {
				this.lyricMode = this.lyricMode+1;
				this.lyricMode = this.lyricMode%3;
				if(this.lyricMode == 0)
				{
					this.showLyric = true;
					uni.showToast({
						title: "显示英文字幕"
					});
				}
				else if(this.lyricMode == 1)
				{
					this.showLyric = true;
					uni.showToast({
						title: "显示中英文字幕"
					});
				}
				else if(this.lyricMode == 2)
				{
					this.showLyric = false;
					uni.showToast({
						title: "隐藏字幕"
					});
					
				}

			},
			showOrHideNotes: function() {
				this.showNotes = !this.showNotes;
				if (this.showNotes)
					uni.showToast({
						title: "显示笔记"
					});
				else
					uni.showToast({
						title: "隐藏笔记"
					});
			},
			showAllNotes:function(){
				uni.showModal({
					title:"长按操作提示",
					content:"将所有句子显示为听不懂,继续?",
					success: (res) => {
						if(res.confirm)
						{
							this.filters.splice(0);// ddelete all
							this.filters.splice(0,0,...this.sentences);
						}
							
					},
					fail: () => {
						
					}
				});
			},
			setheight: function() {
				const res = uni.getSystemInfoSync();
				console.log(res.windowHeight);
				let h = 0;

				let view = uni.createSelectorQuery().select('#player')
				view.fields({
					size: true
				}, data => {
					h = Math.floor(data.height)
				}).exec();
				this.lyricHeight = res.windowHeight - 112; //46 是听不懂按钮 28是滑动条 36是控制菜单
				console.log(res.screenHeight);
			},
			// 播放
			playAndPause: function() {
				//this.setheight();

				if (this.playStatus == false) {
					this.videoContext.play();
					this.playStatus = true;
				} else {
					this.videoContext.pause();
					this.playStatus = false;
				}
			},
			//这里的判断逻辑需要修正一下，start end 中间有较大空白  start end  ，中间较大空白是没有歌词对应的，这时候就会添加失败  这个想法是错的，//如果没找到，保持上一句即可
			querySentence: function(position) {  
				//找到包含position这个时间点的句子
				for (var i = 0; i < this.sentences.length; i++) {
					var sentence = this.sentences[i];
					
					if (position >= (sentence.StartTime - 0.15) && position < sentence.EndTime) {  //r如果以这样的方式找到了，直接返回
						return sentence;
					}
				}
			},
			matchFilterSentence: function(sentence) {
				for (let key of ['StartTime', 'EndTime', 'Value']) {
					if (this.currentfilter[key] != sentence[key]) {
						return false;
					}
				}
				return true;
			},
			exisitsInFilters: function(itemToSearch) {
				this.currentfilter = this.currentSentence;
				if (this.filters.findIndex(this.matchFilterSentence) >= 0) {
					return true;
				}
				var floatEqual = function(n1, n2) {
					return Math.abs(n1 - n2) < 0.1
				};
				var sentenceEqual = function(s1, s2) {
					return (floatEqual(s1.StartTime, s2.StartTime) && s1.Value == s2.Value);
				}
				//因为可能有从localStorage中加载的句子，他们不能简单的进行引用比较
				//因此要再进行内容搜索
				for (var i = 0; i < this.filters.length; i++) {
					var item = this.filters[i];
					if (sentenceEqual(item, itemToSearch)) {
						return true;
					}
				}
				return false;
			},
			addToFilter: function() {
				//把听不懂的一句话加入filters
				//加入筛选
				if (this.currentSentence && !this.exisitsInFilters(this.currentSentence)) {
					var value = this.currentSentence.Value;
					value = value.replace(/[^a-zA-Z0-9]+/gi, ''); //remove all the non-alphanumeric characters
					if (value.length > 0) //some transcript is only "..." or empty string,so skip them
					{
						this.filters.push(this.currentSentence);
					}
					uni.setStorage({
						key: "filters_" + this.currentAudio,
						data: JSON.stringify(this.filters),
						success: (res) => {
							console.log("filter save success");
						},
						fail: () => {
							console.log("filter save fail");
						}
					});
				}
			},
			playSentence: function(sentence) {
				//播放筛选出来的一句话
				this.isSentenceLoop = false; //点击任何一句话，就停止单句循环播放
				this.sentenceEnd = sentence.EndTime; //片段停止播放时间点
				//从片段开始播放
				var cTime = sentence.StartTime;
				this.currentTime = cTime;
				let tempTime = this.currentTime - 0.15;
				if(tempTime < 0)
					tempTime = 0;
				this.videoContext.seek(tempTime) //更新音乐播放的位置
				this.videoContext.play();
				this.playStatus = true;
			},
			// 更新进度条
			timeupdate: function(event) {//调用间隔，0.25
				//console.log(new Date().getTime());
				if (this.lock) return; // 锁
				var currentTime, duration;
				if (event.detail.detail) {
					currentTime = event.detail.detail.currentTime;
					duration = event.detail.detail.duration;
				} else {
					currentTime = event.detail.currentTime;
					duration = event.detail.duration;
				}
				this.currentTime = currentTime;
				this.duration = duration;
				//console.log(this.currentTime);
				//deal with one sentence loop
				if (this.currentTime && (this.currentTime + 0.4) >= this.sentenceEnd) {//其实等于是不行的，因为已经到下一句了 
					if (this.isSentenceLoop) {
						this.playSentence(this.currentSentence);
						this.isSentenceLoop = true;
					} else {
						this.videoContext.pause();
						this.playStatus = false;
						this.sentenceEnd = Number.MAX_VALUE;
					}
				}
				if (this.isSentenceLoop == false) {
					let foundSentence = this.querySentence(this.currentTime);
					if (foundSentence && foundSentence != this.currentSentence) {
						this.currentSentence = foundSentence;
						this.logSentenceNumber();
						
						//mark finished
						this.currentfilter = foundSentence;
						let currentSentenceIndex = this.sentences.findIndex(this.matchFilterSentence);
						if (currentSentenceIndex >= (this.sentences.length - 1)) {
							//标记为finished
							uni.setStorage({
								key: "finised_" + this.currentAudio,
								data: true,
								success: () => {
									console.log("mark finished success");
								},
								fail: () => {
									console.log("mark finished fail");
								}
							})
						}
					}
				}
			},
			goPrevSentence: function() {
				//跳到上一句
				//找到包含当前时间点的句子的序号
				var currentSentenceIndex = -1;
				if (this.currentSentence) {
					this.currentfilter = this.currentSentence;
					currentSentenceIndex = this.sentences.findIndex(this.matchFilterSentence);
				}
				//上一句的序号
				var prevSentenceIndex = currentSentenceIndex - 1;
				if (prevSentenceIndex >= 0) {
					var prevSentence = this.sentences[prevSentenceIndex];
					this.currentTime = prevSentence.StartTime; //更新进度条左边的时间点，应该要换算一下
					let tempTime = this.currentTime -0.15;
					if(tempTime < 0)
						tempTime = 0;
					this.videoContext.seek(tempTime); //更新音乐播放的位置
					this.videoContext.play();
					this.playStatus = true;
					//this.currentSentence = prevSentence;  //直接依赖update time 更新currentSentence即可，这里更新会引起闪动
				} else {
					uni.showToast({
						title: "这是第一句了"
					})
				}
			},
			goNextSentence: function() {
				//this.timeupdate();//因为在暂停情况下拖动进度条，TimeUpdate事件不会执行
				//因为也就不会根据当前进度更新this.currentSentence
				//这样就会造成在暂停状态下点击【Next】不准确，因此手动更新一下this.currentSentenc
				//跳到下一句（比如当前是一大段的空白）

				//找到包含当前时间点的句子的序号
				var currentSentenceIndex = -1;
				if (this.currentSentence) {
					this.currentfilter = this.currentSentence;
					currentSentenceIndex = this.sentences.findIndex(this.matchFilterSentence);
				}
				//下一句的序号
				var nextSentenceIndex = currentSentenceIndex + 1;
				var nextSentence;
				if (nextSentenceIndex < this.sentences.length) {
					nextSentence = this.sentences[nextSentenceIndex];
				} else //如果已经到最后一句，则从头开始
				{
					nextSentence = this.sentences[0];
				}
				
				this.currentTime = nextSentence.StartTime; //更新进度条左边的时间点，应该要换算一下
				let tempTime = this.currentTime -0.15;
				if(tempTime < 0)
					tempTime = 0;
				this.videoContext.seek(tempTime); //更新音乐播放的位置
				this.videoContext.play();
				this.playStatus = true;
				//this.currentSentence = nextSentence;  //直接依赖update time 更新currentSentence即可，这里更新会引起闪动

			},
			// 拖动进度条
			sliderChange: function(data) {
				this.isSentenceLoop = false;
				this.videoContext.seek(data.detail.value);
				//更新sentence位置
				let foundSentence = this.querySentence(this.currentTime);
				if (foundSentence && foundSentence != this.currentSentence) {
					this.currentSentence = foundSentence;
					
				}
			},

			//拖动中
			sliderChanging: function(data) {
				this.currentTime = data.detail.value;
				//更新sentence位置
				let foundSentence = this.querySentence(this.currentTime);
				if (foundSentence && foundSentence != this.currentSentence) {
					this.currentSentence = foundSentence;
				}
			},

			// 视频加载完成
			loadedmetadata: function(data) {
				this.duration = data.detail.duration
			},
			showtabbar: function() {
				//跳出播放页，如果进度条没有回归的话，会出现假死的现象
				this.videoContext.seek(0);
				this.currentTime = 0;
				this.videoContext.pause();
				this.playStatus = false; //因为开启了自动播放
				uni.switchTab({
					url: "../alist/index"
				});


			},
			bindPickerChange: function(event) {
				let array = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
				this.index = event.detail.value;
				let pickRate = array[this.index];
				this.setRate(pickRate);
			},
			showSentenceCtxMenu: function(sentence) {
				let that = this;
				let itemList;
				if (this.isSentenceLoop)
					itemList = ['关闭循环', '翻译', '删除', '报错'];
				else
					itemList = ['单句循环', '翻译', '删除', '报错'];
				uni.showActionSheet({
					itemList: itemList,
					success: function(res) {
						//console.log('选中了第' + (res.tapIndex + 1) + '个按钮');

						if (res.tapIndex == 0) {
							if (that.isSentenceLoop)
								that.stopSentenceLoop();
							else
								that.startSentenceLoop(sentence);
						}
						if (res.tapIndex == 1) {
							uni.showModal({
								title: '翻译',
								content: sentence["Value"] + '\n' + sentence["trans"],
								showCancel: false,
								success: function(res) {
									if (res.confirm) {
										console.log('用户点击确定');
									}
								}
							});
						}
						if (res.tapIndex == 2) {
							that.removeFromFilters(sentence);
						}
						if (res.tapIndex == 3) {
							uni.showActionSheet({
								itemList: ["句子太长", "字幕有错误", "时间点错位"],
								success: (res) => {

									let oneReport = {
										'link': that.currentAudio,
										'sentence': JSON.parse(JSON.stringify(sentence)),
										'errorType': ["句子太长", "字幕有错误", "时间点错位"][res.tapIndex]
									};
									uniCloud.callFunction({
										name: "report",
										data: oneReport
									})
								},
								fail: (res) => {
									console.log(res.errMsg);
								}
							});
						}
					},
					fail: function(res) {
						console.log(res.errMsg);
					}
				});
			},
			removeFromFilters: function(filterToRemove) {
				this.currentfilter = filterToRemove;
				var i = this.filters.findIndex(this.matchFilterSentence);
				this.filters.splice(i, 1);
				if(this.filters.length == 0){
					this.isSentenceLoop = false;
				}
				uni.setStorage({
					key: "filters_" + this.currentAudio,
					data: JSON.stringify(this.filters),
					success: (res) => {
						console.log("filter save success");
					},
					fail: () => {
						console.log("filter save fail");
					}
				});
			},
			startSentenceLoop: function(sentence) {
				this.currentSentence = sentence;
				this.playSentence(sentence);
				this.isSentenceLoop = true;
			},
			stopSentenceLoop: function() {
				//拖动进度条也停止单句循环
				this.isSentenceLoop = false;
			},
		}
	}

	function calcTimer(timer) {
		if (timer === 0 || typeof timer !== 'number') {
			return '00:00'
		}
		let mm = Math.floor(timer / 60)
		let ss = Math.floor(timer % 60)
		if (mm < 10) {
			mm = '0' + mm
		}
		if (ss < 10) {
			ss = '0' + ss
		}
		return mm + ':' + ss
	}
</script>

<style>

	.container {
		display: flex;
		flex-direction: row-reverse;
	}

	.item {
		width: 40px;
		height: 40px;
		/* background-color: #007AFF; */
		display: inline-block;
		margin: 2px;
		align-self: center;
	}

	#lyric {
		padding: 5px 10px;
		overflow: hidden;
		white-space: nowrap;
	}

	.content {
		height: 100%;
		width: 100%;
		display: flex;
		flex-direction: column;
		/* align-items: center; */
		/* justify-content: center; */
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}

	.footer {
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
	}
</style>
<style scoped lang="scss">
	.audo-video {
		padding-bottom: 2upx;
	}

	.slider-box {
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 26upx;
		color: #999;
	}

	button {
		display: inline-block;
		width: 100upx;
		background-color: #fff;
		font-size: 24upx;
		color: #000;
		padding: 0;
	}

	.hidden {
		position: fixed;
		height: 250px;
		width: 250px;
		left: -400px;
		top: -400px;
	}

	.iconbtn {
		display: block;
		width: 50upx;
		height: 50upx;
		margin: 0 auto;
	}

	.control {
		display: flex;
		flex-direction: row;
		flex-wrap: nowrap;
		line-height: 1;
		justify-content: space-around;
	}
</style>
