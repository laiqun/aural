<template>
	<view>
		<!-- <view class="uni-title uni-common-pl">选择级别</view> -->
		<ad unit-id="adunit-13953bb44d7fb81d" style="position: fixed;bottom: 55px;"></ad>
		<uni-list>
			<!-- 		    <uni-list-item title="今天学习: 2句"  thumb="https://img-cdn-qiniu.dcloud.net.cn/new-page/uni.png"
		      rightText="第8名"></uni-list-item> -->
			<uni-list-item :title="achievestring" thumb="/static/award.png"></uni-list-item>
			<uni-list-item thumb="/static/time.png" link to="/pages/recent/index" title="最近在听"></uni-list-item>
			<!--哪一套，哪一句听不懂-->
			<uni-list-item></uni-list-item> 
			
			
			<!-- <ad  style="position: fixed;bottom: 55px;" unit-id="adunit-23e0b176670e3fa9" ad-type="video" ad-theme="white"></ad> -->
			<!-- <uni-list-item thumb="https://img-cdn-qiniu.dcloud.net.cn/new-page/uni.png"  clickable title="分享" open-type="share" ></uni-list-item> -->
		</uni-list>
		<button open-type="share">打卡转发</button>
		<button open-type="contact" style="position: fixed;bottom: 0;left: 0;right: 0; height: 46px; color: #FF3333;">联系客服</button>
		<!-- <button @tap="showRecent">test</button> -->
		<!-- <button>已完成的卷子 这个不要了，在列表后面显示一个对号，表示完成；否则就是未完成；所有都听懂，没有听不懂标记为完成</button> -->
	</view>

</template>

<script>
	// import {
	// 	mapState,
	// 	mapMutations
	// } from 'vuex'
	export default {
		data() {
			return {
				achievestring: "今天学习: 0句"
			}
		},
		onLoad() {

		},
		computed: {

		},
		onShow() {
			let temp = uni.getStorageSync("achieve");
			// temp format 
			// date:"" number
			// 获取当前日期  如果当前日期和记录日期相同，显示数组，否则显示0
			let stringDate = new Date();
			let strDate = `${stringDate.getFullYear()}/${stringDate.getMonth()+1}/${stringDate.getDate()}`;
			if (temp) {
				try {
					if (temp['date'] == strDate) {
						this.achievestring =  `今天学习: ${temp['number']}句`;
					} else {
						this.achievestring =  "今天学习: 0句";
					}
				} catch (e) {
					this.achievestring =  "今天学习: 0句";
				}
			} else
				this.achievestring =  "今天学习: 0句";

		},
		methods: {
			// showRecent:function(){
			// 	console.log('show rec');
			// 	uni.switchTab({
			// 		url: "../recent/index"
			// 	});
			// }
		},
		onShareAppMessage: function() {
			return {
				title: '一句话反复听，带翻译的听力。',
				path: 'pages/alist/index'
			};
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
