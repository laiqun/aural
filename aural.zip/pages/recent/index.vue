<template>
	<view class="content">
		<!-- 		<view class="uni-list" style="background-color: #F1F1F1;">
			<view class="uni-list-cell">
				<view class="uni-list-cell-left">
					选择当前级别:
				</view>
				<view class="uni-list-cell-db">
					<picker @change="bindPickerChange" :value="index" :range="array" range-key="name">
						<view class="uni-input">{{array[index].name}}</view>
					</picker>
				</view>
			</view>
		</view>
		<progress  id="process" percent=0 show-info stroke-width="3"  style="margin: 5px 0;"/> -->
		<view class="text-area">
			<uni-list>
				<uni-list-item v-for="(item,index) in recentListernList" badgeType="success" :title="item.title.split(']')[1]"
				 :show-badge="item.finish" badge-text="✔" :key="index" clickable @click="itemclick(item,)"></uni-list-item>

				<!-- 				<uni-list-item  v-for="(item,index) in currentPlayList"  badgeType="warning" :title="item.name" :show-badge="item.finish" badge-text="✔" :key="index" clickable @click="itemclick(item.name,)"></uni-list-item>
 -->
				<!--<uni-list-item  v-for="(item,index) in discList"  badgeType="success" :title="item.name" :show-badge="item.finish" badge-text="✔" :key="item.name" clickable @click="itemclick(item.name,)"></uni-list-item>
				所有都听懂，为绿色； 听了但是有句子没听懂，为黄色-->
			</uni-list>
		</view>

	</view>
</template>

<script>
	//        完善46级
	//        完善finish标记的功能
	// import {
	// 	mapState,
	// 	mapMutations
	// } from 'vuex'
	export default {
		data() {
			return {}
		},
		computed: {
			//...mapState(['currentPlayList'])
			recentListernList: function() {
				let that = this;
				uni.showTabBar({});
				const value = uni.getStorageSync("recentListernList");
				if (value) {
					//判断是否finished
					for (let item of value) {
						let finished = uni.getStorageSync("finised_" + item["link"]);
						if (finished)
							item['finish'] = true;
						else
							item['finish'] = false;
					}
				}
				return value;
			}

		},
		onLoad() {

		},
		onShow() {

		},
		methods: {
			//选中后，保持高亮
			//加入click事件
			//...mapMutations(['SET_AUDIO', 'SET_QUARTER']),
			itemclick: function(e) {
				// for(let item of this.audioList){
				// if(item["name"] == e){
				// 	item.finish=false;
				// }
				// }
				console.log(e.link);
				//this.SET_AUDIO(e.link);
				//this.SET_QUARTER(e.title.split(']')[1]);

				uni.setStorageSync("song",{"link":e.link,"title":e.title.split(']')[1],"mylevel":e["mylevel"]});
				//跳转到音乐播放页面
				uni.switchTab({
					url: "../player/index"
				});
			}
		}
	}
</script>

<style>


</style>
