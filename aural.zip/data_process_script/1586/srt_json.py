import json
from decimal import  Decimal
start = False
findTime = False
oneData = {}
result = []
with open("sentences.srt",encoding='utf-8') as file:
    i = 1
    for line in file.readlines():
        if(line == (str(i) + '\n')):#找到数字标号，那么处理下一行
            start = True
            i = i + 1
            continue
        if(line.find("-->")!=-1 and start):#处理时间
            oneData = {}
            line = line.replace("\n","")
            timestrs = line.split(' --> ')
            startstr = timestrs[0]
            endstr = timestrs[1]
            splitminsec = startstr.split(",")
            xxxx = splitminsec[0].split(":")
            hour = int(xxxx[0])*60*60
            min = int(xxxx[1])*60
            sec = int(xxxx[2])
            minsec = int(splitminsec[1]) * 0.001
            startTime = hour + min+sec+minsec

            splitminsec = endstr.split(",")
            xxxx = splitminsec[0].split(":")
            hour = int(xxxx[0])*60*60
            min = int(xxxx[1])*60
            sec = int(xxxx[2])
            minsec = int(splitminsec[1]) * 0.001
            endTime = hour + min+sec+minsec
            oneData["StartTime"] = startTime
            oneData["EndTime"] = endTime
            start = False
            findTime = True
            continue
        if(findTime):
            oneData["Value"] = line.replace('\n','')
            findTime = False
            #写入数据
            result.append(oneData)


contentAddTrans = json.dumps(result, ensure_ascii=False)
#contentAddTrans = contentAddTrans#.encode('utf-8').decode('unicode_escape')
#if os.path.exists('after'):
#    pass
#else:
#    os.mkdir('after')
filewrite = open('sentences_srt.json','w',encoding='utf-8')
filewrite.write(contentAddTrans)
filewrite.close()
