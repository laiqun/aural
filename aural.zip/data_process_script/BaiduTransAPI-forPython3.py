#百度通用翻译API,不包含词典、tts语音合成等资源，如有相关需求请联系translate_api@baidu.com
# coding=utf-8
from __future__ import unicode_literals
import http.client
import hashlib
import urllib
import random
import json
import  os
def processOne():
    if os.path.exists('sentences.json'):
        os.rename('sentences.json','sentences_old.json')
    file = open('sentences_old.json',encoding='utf-8')
    content = file.read()
    sentences = json.loads(content)
    appid = '20200918000568754'  # 填写你的appid
    secretKey = 'DmHV31nheYOOH6YskJTJ'  # 填写你的密钥
    def transOne(q):
        httpClient = None
        myurl = '/api/trans/vip/translate'

        fromLang = 'auto'   #原文语种
        toLang = 'zh'   #译文语种
        salt = random.randint(32768, 65536)
        #q= 'apple'
        sign = appid + q + str(salt) + secretKey
        sign = hashlib.md5(sign.encode()).hexdigest()
        myurl = myurl + '?appid=' + appid + '&q=' + urllib.parse.quote(q) + '&from=' + fromLang + '&to=' + toLang + '&salt=' + str(
        salt) + '&sign=' + sign

        try:
            httpClient = http.client.HTTPConnection('api.fanyi.baidu.com')
            httpClient.request('GET', myurl)

            # response是HTTPResponse对象
            response = httpClient.getresponse()
            result_all = response.read().decode("utf-8")
            result = json.loads(result_all)

            return result["trans_result"][0]["dst"]

        except Exception as e:
            print (e)
        finally:
            if httpClient:
                httpClient.close()
    i = 0
    for sentence in sentences:
        trans = transOne(sentence["Value"])
        sentence["trans"] = trans
        #break
        i = i+1
        print(i/len(sentences))
        
    contentAddTrans = json.dumps(sentences, ensure_ascii=False)



    contentAddTrans = contentAddTrans#.encode('utf-8').decode('unicode_escape')
    #if os.path.exists('after'):
    #    pass
    #else:
    #    os.mkdir('after')
    filewrite = open('sentences.json','w',encoding='utf-8')
    filewrite.write(contentAddTrans)
    filewrite.close()

filelist = os.listdir('./')
root = os.getcwd()
for path in filelist:
    if os.path.isdir(path):
        os.chdir(path)
        processOne()
        print(os.getcwd() )
        os.chdir(root)
    else:
        pass